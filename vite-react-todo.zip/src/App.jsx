import { useEffect, useState } from 'react'
// import { FaDizzy } from "react-icons/gi";
import { v4 as uuidv4 } from 'uuid';

import { FaCheck, FaCircle } from "react-icons/fa";

import './App.css'
import _ from 'lodash';
import axios from 'axios'

const ApiClient = axios.create({
  baseURL: 'http://localhost:3001',
  withCredentials: true,
  headers: {
    'Content-Type': 'application/json',
  }
});

function App() {
  const [count, setCount] = useState(0);
  const [todo, setTodo] = useState("");
  const [todos, setTodos] = useState([]);

  const setTodosEvent = async () => {
    const _todo = { id: uuidv4(), value: todo, checked: false }

    await ApiClient.post(`/todo`, _todo).then(async () => {
      console.log('setTodosEvent')
      setTodo("");
      await getTodos();
    })
  }

  const getTodos = async () => {
    ApiClient.get(`/todo`).then(async (res) => {
      if (res.data) {
        setTodos(res.data)
      }
    })
  }

  const setTodoEvent = (value) => {
    setTodo(value)
  }

  const setTodoCheckdEvent = async (id , checked) => {
    
    await ApiClient.put(`/todo`, {id , checked : !checked}).then(async () => {
      await getTodos();
    })
  }

  useEffect(() => {
    const _getTodo = async () => {
      console.log('useEffect')
      await getTodos();
    }
    _getTodo();
  }, []);

  return (
    <div className="App">
      <input type="text" value={todo} onChange={(e) => setTodoEvent(e.target.value)}></input>
      <input type="button" onClick={() => setTodosEvent()} value="저장"></input>

      {
        todos.map((element, index) => {
          return <div key={index} style={{ display: 'flex', justifyContent: 'center' }}>
            <div onClick={() => setTodoCheckdEvent(element.id , element.checked)}>
              {element.checked ? <FaCheck /> : <FaCircle />}
            </div>
            {element.value}
          </div>
        })
      }
    </div>
  )
}

export default App
