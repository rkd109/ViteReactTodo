import axios from 'axios'

const ApiClient = axios.create({
    baseURL: 'http://localhost:3001',
    withCredentials: true,
    headers: {
        'Content-Type': 'application/json',
    }
});

export const todoPost = async (callback) => {
    await ApiClient.post(`/todo`, _todo).then(async () => {
        if (callback) {
            await callback();
        }
    })
}

